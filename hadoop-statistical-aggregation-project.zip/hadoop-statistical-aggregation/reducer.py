#!/usr/bin/env python3
"""Hadoop Streaming reducer: combine mapper outputs and calculate statistics."""
import sys
from collections import defaultdict

totals = defaultdict(float)

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        key, value = line.split("\t", 1)
        totals[key] += float(value)
    except ValueError:
        continue

count = int(totals["STAT_COUNT"])
total = totals["STAT_SUM"]
sum_squares = totals["STAT_SUM_SQUARES"]

if count:
    mean = total / count
    # Population variance: E[X^2] - (E[X])^2
    variance = max(0.0, (sum_squares / count) - (mean ** 2))
    std_dev = variance ** 0.5

    print(f"Total_Records\t{count}")
    print(f"Sum\t{total:.2f}")
    print(f"Mean\t{mean:.2f}")
    print(f"Population_Variance\t{variance:.2f}")
    print(f"Population_Standard_Deviation\t{std_dev:.2f}")

for key in sorted(k for k in totals if k.startswith("FREQ_")):
    print(f"Frequency_{key[5:]}\t{int(totals[key])}")
