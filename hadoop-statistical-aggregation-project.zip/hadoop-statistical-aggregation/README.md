# Hadoop MapReduce Statistical Aggregation

A Hadoop Streaming project that processes numerical marks stored in HDFS and calculates count, sum, mean, population variance, population standard deviation, and frequency distribution using Python Mapper and Reducer programs.

## Project structure

```text
hadoop-statistical-aggregation/
├── dataset/
│   └── marks.csv
├── mapper.py
├── reducer.py
├── output/
│   └── expected_output.txt
├── raw_calculations.xlsx
└── README.md
```

## Requirements

- Hadoop with HDFS and MapReduce/YARN configured
- Python 3 on the machine/container running Hadoop Streaming
- Hadoop Streaming JAR (path varies by Hadoop installation)

## Run locally first (sanity check)

```bash
cat dataset/marks.csv | python3 mapper.py | sort | python3 reducer.py
```

## Run using Hadoop Streaming

Start HDFS and YARN using your Hadoop installation's normal commands, then create the HDFS input directory and upload the CSV:

```bash
hdfs dfs -mkdir -p /user/$USER/statistics/input
hdfs dfs -put -f dataset/marks.csv /user/$USER/statistics/input/
```

Run the job (replace the JAR path with the Hadoop Streaming JAR installed on your system):

```bash
hadoop jar /path/to/hadoop-streaming.jar \
  -files mapper.py,reducer.py \
  -mapper "python3 mapper.py" \
  -reducer "python3 reducer.py" \
  -input /user/$USER/statistics/input/marks.csv \
  -output /user/$USER/statistics/output
```

View the result:

```bash
hdfs dfs -cat /user/$USER/statistics/output/part-*
```

If the output directory already exists, remove it before rerunning:

```bash
hdfs dfs -rm -r /user/$USER/statistics/output
```

## Expected result for the supplied sample

```text
Total_Records                    10
Sum                              675.00
Mean                             67.50
Population_Variance              206.25
Population_Standard_Deviation    14.36
Frequency_40-49                  1
Frequency_50-59                  2
Frequency_60-69                  2
Frequency_70-79                  2
Frequency_80-89                  2
Frequency_90-99                  1
```

**Important:** This project calculates population variance (dividing by N), not sample variance (dividing by N-1). The expected output is for the included 10-row sample dataset. The Hadoop output should match the local sanity-check output.

## Notes

- The Mapper emits partial count, sum, sum of squares, and frequency-bucket values.
- Hadoop Streaming sorts intermediate keys before passing them to the Reducer.
- The Reducer combines the values and calculates the final statistics.
- The sample is intentionally small for manual verification. You can replace it with a larger CSV containing `Student_ID,Marks` columns.
