#!/usr/bin/env python3
"""Hadoop Streaming mapper: emit partial statistics and mark-range frequencies."""
import sys
import csv

def bucket(mark):
    lower = (mark // 10) * 10
    return f"{lower}-{lower + 9}"

reader = csv.reader(sys.stdin)
for row in reader:
    if not row:
        continue
    # Skip the CSV header.
    if row[0].strip().lower() in {"student_id", "id"}:
        continue
    try:
        mark = float(row[1])
    except (IndexError, ValueError):
        continue

    # Each record contributes to the global aggregate.
    print(f"STAT_COUNT\t1")
    print(f"STAT_SUM\t{mark}")
    print(f"STAT_SUM_SQUARES\t{mark * mark:.10f}")

    # Each record contributes to one frequency bucket.
    print(f"FREQ_{bucket(int(mark))}\t1")
